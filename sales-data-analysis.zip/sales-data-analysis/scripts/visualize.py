"""
visualize.py
Builds the visual reports/charts for the Sales Data Analysis project,
designed to communicate findings clearly to non-technical stakeholders.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import seaborn as sns

CLEAN_PATH = "/home/claude/sales_project/data/sales_data_clean.csv"
OUT = "/home/claude/sales_project/charts"

sns.set_theme(style="whitegrid", font_scale=1.05)
PALETTE = "viridis"

df = pd.read_csv(CLEAN_PATH, parse_dates=["date"])
month_order = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
df["month_name"] = pd.Categorical(df["month_name"], categories=month_order, ordered=True)

def money(ax, axis="y"):
    fmt = mtick.FuncFormatter(lambda x, _: f"${x:,.0f}")
    (ax.yaxis if axis == "y" else ax.xaxis).set_major_formatter(fmt)

# ------------------------------------------------------------------
# 1. Monthly revenue trend (line chart)
# ------------------------------------------------------------------
monthly = df.groupby(pd.Grouper(key="date", freq="MS"))["revenue"].sum().reset_index()
fig, ax = plt.subplots(figsize=(11, 5))
ax.plot(monthly["date"], monthly["revenue"], marker="o", color="#2E5EAA", linewidth=2)
ax.fill_between(monthly["date"], monthly["revenue"], color="#2E5EAA", alpha=0.08)
ax.set_title("Monthly Revenue Trend (2023–2024)", fontsize=15, fontweight="bold")
ax.set_xlabel("")
ax.set_ylabel("Revenue")
money(ax)
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(f"{OUT}/01_monthly_revenue_trend.png", dpi=150)
plt.close(fig)

# ------------------------------------------------------------------
# 2. Top 10 products by revenue (horizontal bar)
# ------------------------------------------------------------------
top_products = df.groupby("product")["revenue"].sum().sort_values(ascending=True).tail(10)
fig, ax = plt.subplots(figsize=(9, 6))
colors = sns.color_palette(PALETTE, len(top_products))
ax.barh(top_products.index, top_products.values, color=colors)
ax.set_title("Top 10 Products by Revenue", fontsize=15, fontweight="bold")
ax.set_xlabel("Revenue")
money(ax, axis="x")
for i, v in enumerate(top_products.values):
    ax.text(v, i, f"  ${v:,.0f}", va="center", fontsize=9)
fig.tight_layout()
fig.savefig(f"{OUT}/02_top_products.png", dpi=150)
plt.close(fig)

# ------------------------------------------------------------------
# 3. Seasonal pattern: revenue by calendar month
# ------------------------------------------------------------------
by_month = df.groupby("month_name", observed=True)["revenue"].sum()
fig, ax = plt.subplots(figsize=(10, 5))
colors = ["#C0504D" if m in ("Nov", "Dec", "Jan") else "#4472C4" for m in by_month.index]
ax.bar(by_month.index, by_month.values, color=colors)
ax.set_title("Seasonal Sales Pattern — Revenue by Month (2023–2024 combined)",
             fontsize=14, fontweight="bold")
ax.set_ylabel("Revenue")
money(ax)
fig.tight_layout()
fig.savefig(f"{OUT}/03_seasonal_pattern.png", dpi=150)
plt.close(fig)

# ------------------------------------------------------------------
# 4. Revenue by category (donut chart)
# ------------------------------------------------------------------
by_cat = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(7, 7))
colors = sns.color_palette(PALETTE, len(by_cat))
wedges, texts, autotexts = ax.pie(
    by_cat.values, labels=by_cat.index, autopct="%1.1f%%",
    startangle=90, colors=colors, pctdistance=0.8,
    wedgeprops=dict(width=0.4, edgecolor="white")
)
ax.set_title("Revenue Share by Category", fontsize=15, fontweight="bold")
fig.tight_layout()
fig.savefig(f"{OUT}/04_category_share.png", dpi=150)
plt.close(fig)

# ------------------------------------------------------------------
# 5. Category revenue by month (heatmap) - deeper seasonal view
# ------------------------------------------------------------------
pivot = df.pivot_table(index="category", columns="month_name", values="revenue",
                        aggfunc="sum", observed=True).reindex(columns=month_order)
fig, ax = plt.subplots(figsize=(12, 4.5))
sns.heatmap(pivot, cmap="YlGnBu", annot=False, cbar_kws={"label": "Revenue"}, ax=ax)
ax.set_title("Revenue by Category and Month", fontsize=15, fontweight="bold")
ax.set_xlabel("")
ax.set_ylabel("")
fig.tight_layout()
fig.savefig(f"{OUT}/05_category_month_heatmap.png", dpi=150)
plt.close(fig)

# ------------------------------------------------------------------
# 6. Revenue by region and channel (grouped bar)
# ------------------------------------------------------------------
by_region_channel = df.groupby(["region", "channel"])["revenue"].sum().unstack()
fig, ax = plt.subplots(figsize=(10, 5.5))
by_region_channel.plot(kind="bar", ax=ax, color=["#4472C4", "#ED7D31"])
ax.set_title("Revenue by Region and Sales Channel", fontsize=15, fontweight="bold")
ax.set_xlabel("")
ax.set_ylabel("Revenue")
money(ax)
plt.xticks(rotation=0)
ax.legend(title="Channel")
fig.tight_layout()
fig.savefig(f"{OUT}/06_region_channel.png", dpi=150)
plt.close(fig)

print("All charts saved to", OUT)
