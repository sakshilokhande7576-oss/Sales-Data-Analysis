"""
analyze.py
Exploratory Data Analysis on the sales dataset.
Cleans/transforms raw data with Pandas & NumPy, then surfaces
revenue trends, top products, and seasonal patterns.
"""
import numpy as np
import pandas as pd

RAW_PATH = "/home/claude/sales_project/data/sales_data_raw.csv"
CLEAN_PATH = "/home/claude/sales_project/data/sales_data_clean.csv"

# ------------------------------------------------------------------
# 1. LOAD
# ------------------------------------------------------------------
df = pd.read_csv(RAW_PATH, parse_dates=["date"])
print("=== RAW DATA OVERVIEW ===")
print(f"Rows: {len(df)}  |  Columns: {list(df.columns)}")
print(df.isna().sum())

# ------------------------------------------------------------------
# 2. CLEAN & TRANSFORM
# ------------------------------------------------------------------
before = len(df)

# 2a. Standardize categorical text (fix inconsistent casing)
df["region"] = df["region"].str.strip().str.title()

# 2b. Remove exact duplicate transactions
df = df.drop_duplicates(subset=["order_id", "product", "date", "quantity", "unit_price"])

# 2c. Drop invalid quantities (negative / zero = data entry errors)
df = df[df["quantity"] > 0]

# 2d. Impute missing unit_price using the median price for that product
df["unit_price"] = df.groupby("product")["unit_price"].transform(
    lambda s: s.fillna(s.median())
)

# 2e. Recompute revenue after cleaning (NumPy vectorized calc)
df["revenue"] = np.round(df["quantity"].to_numpy() * df["unit_price"].to_numpy(), 2)

# 2f. Add time-based features for trend/seasonality analysis
df["year"] = df["date"].dt.year
df["month"] = df["date"].dt.month
df["month_name"] = df["date"].dt.strftime("%b")
df["quarter"] = df["date"].dt.quarter
df["weekday"] = df["date"].dt.day_name()
df["is_weekend"] = df["date"].dt.weekday >= 5

after = len(df)
print(f"\n=== CLEANING SUMMARY ===")
print(f"Rows before: {before}  |  Rows after: {after}  |  Removed: {before - after}")
print(f"Missing unit_price values remaining: {df['unit_price'].isna().sum()}")

df.to_csv(CLEAN_PATH, index=False)

# ------------------------------------------------------------------
# 3. KEY METRICS
# ------------------------------------------------------------------
total_revenue = df["revenue"].sum()
total_orders = df["order_id"].nunique()
avg_order_value = df.groupby("order_id")["revenue"].sum().mean()

print(f"\n=== KEY METRICS ===")
print(f"Total Revenue: ${total_revenue:,.2f}")
print(f"Total Orders (line items): {total_orders:,}")
print(f"Average Order Value: ${avg_order_value:,.2f}")

# ------------------------------------------------------------------
# 4. TOP-PERFORMING PRODUCTS
# ------------------------------------------------------------------
top_products = (
    df.groupby("product")["revenue"]
    .sum()
    .sort_values(ascending=False)
    .head(10)
)
print("\n=== TOP 10 PRODUCTS BY REVENUE ===")
print(top_products.round(2))

top_categories = (
    df.groupby("category")["revenue"].sum().sort_values(ascending=False)
)
print("\n=== REVENUE BY CATEGORY ===")
print(top_categories.round(2))

# ------------------------------------------------------------------
# 5. SEASONAL / TREND PATTERNS
# ------------------------------------------------------------------
monthly_revenue = df.groupby(pd.Grouper(key="date", freq="MS"))["revenue"].sum()
print("\n=== MONTHLY REVENUE TREND (first & last 3 months) ===")
print(pd.concat([monthly_revenue.head(3), monthly_revenue.tail(3)]).round(2))

avg_by_month = df.groupby("month_name")["revenue"].sum()
month_order = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
avg_by_month = avg_by_month.reindex(month_order)
print("\n=== REVENUE BY CALENDAR MONTH (both years combined) ===")
print(avg_by_month.round(2))

weekday_rev = df.groupby("weekday")["revenue"].mean()
weekday_order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
print("\n=== AVG REVENUE PER TRANSACTION BY WEEKDAY ===")
print(weekday_rev.reindex(weekday_order).round(2))

# ------------------------------------------------------------------
# 6. REGION & CHANNEL BREAKDOWN
# ------------------------------------------------------------------
region_rev = df.groupby("region")["revenue"].sum().sort_values(ascending=False)
print("\n=== REVENUE BY REGION ===")
print(region_rev.round(2))

channel_rev = df.groupby("channel")["revenue"].sum()
print("\n=== REVENUE BY CHANNEL ===")
print(channel_rev.round(2))

print("\nClean dataset saved to:", CLEAN_PATH)
